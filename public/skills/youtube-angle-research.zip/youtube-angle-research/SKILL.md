---
name: youtube-angle-research
description: Research YouTube topic leads and generate strong video angles based on competitor analysis, title patterns, audience fit, and trend signals. Use when the user wants to validate a topic, find better angles, study competing videos, or decide whether a YouTube topic is worth making.
---

# YouTube Angle Research

Research a topic lead, not just the topic itself.

Your job is to decide whether the topic has upside for the creator's audience and, if it does, produce 5 to 6 distinct angles that are more specific, more clickable, and more strategically useful than a generic video idea.

## First Step: Confirm Scope

Before researching, determine what the user wants:
- Validate a topic lead
- Generate better angles for a topic
- Compare competing framings
- Judge whether a topic is worth making now

If required context is missing, ask for it before proceeding.

Useful inputs:
- Topic lead or working title
- Channel niche and audience level
- Preferred format such as tutorial, breakdown, comparison, experiment, or case study
- Constraints such as video length, production effort, publication timing, or topics to avoid
- Whether the user wants a quick verdict or a deeper angle report

If the user does not provide channel context, assume a general audience for the topic and state that assumption.

## Operating Rules

- Distinguish clearly between observed signals, inferred patterns, and recommendations.
- Do not claim exact demand, CTR, or retention outcomes. Frame them as directional judgments.
- Ask follow-up questions only when the missing detail would materially change the recommendation. Otherwise proceed with a stated default.
- Prefer a small number of well-supported ideas over a long list of weak ones.

## What To Optimize For

- Click-through rate
- Audience retention
- Reach
- Novelty within the niche
- Clarity of audience fit

Do not generate generic video ideas. Prefer angles with a clear tension, payoff, comparison, experiment, mistake, contrarian take, or workflow shift.

## Inputs

The user should give a topic lead such as:

- "MCPs with Rust"
- "Claude Code for backend work"
- "Why creators are quitting daily vlogging"

If the user also gives channel context, audience level, video format preferences, or constraints, use them.

If the user provides only a broad topic, narrow it before generating final angles.

## Research Workflow

### 1. Define the topic surface

Turn the lead into 4 to 8 search variants:

- exact topic
- beginner phrasing
- advanced phrasing
- comparison phrasing
- problem-solution phrasing
- controversy phrasing
- trend phrasing

Example for `MCPs with Rust`:

- `mcp rust`
- `model context protocol rust`
- `rust ai agents`
- `rust mcp server`
- `mcp vs api agents`
- `building mcp tools rust`

### 2. Research competitors

Search YouTube for the topic and close variants using whatever search tools are available in the environment.

Collect enough results to answer:

- Which titles and formats are already winning
- Which framing is saturated
- Which audience each video is for
- Whether the topic is still early, rising, or already exhausted

Focus on:

- recent winners
- outlier performers
- repeated title structures
- repeated promises or framing visible from titles and metadata

### 3. Identify performance patterns

Look for patterns such as:

- `I tried X so you don't have to`
- `X changed how I build Y`
- `X vs Y`
- `I built Z with X`
- `The problem with X`
- `Beginner trap / misconception`
- `Full workflow / production reality`

Do not copy titles. Extract the underlying pattern and adapt it.

### 4. Judge topic quality

Before proposing angles, decide whether the topic is:

- `Strong`: clear demand and multiple promising angles
- `Borderline`: possible, but only with a sharper framing
- `Weak`: low demand, poor curiosity, or too saturated without a differentiated take

State briefly which signals led to the verdict.

Reject weak topics. If the lead is weak, say so directly and explain why. Then suggest 2 to 3 adjacent leads with better upside.

### 5. Generate angles

Produce 5 to 6 angles only if they are genuinely distinct.

Each angle must have:

- a clear audience
- a strong curiosity hook
- a reason it can outperform a generic tutorial
- a concrete format

Avoid repeating the same idea with different wording.

If the topic is borderline, prefer 3 to 4 stronger angles over forcing 5 to 6.

## Quality Filter

Discard any angle that fails one of these:

- Immediately understandable in one read
- Clear why the intended viewer would click
- Specific enough to feel like a real video
- Distinct from the other ideas
- Better than `Learn X`

## Output Guidance

Start with a short verdict:

```markdown
## Topic Verdict
{Strong / Borderline / Weak}

## Why
- {demand signal}
- {competition signal}
- {novelty or saturation signal}
```

Then provide the ideas. Match the response depth to the request:
- Quick validation: verdict plus 3 strong angles
- Full research pass: verdict, 4-6 angles, competitive notes, and adjacent leads if needed
- Framing comparison: compare 2-4 possible angles and recommend the strongest one with rationale

When you cite market or competitor signals, keep them concrete and avoid fake precision.

Use a structure like this for each angle:

```markdown
## Angles

### 1. {CTR-optimized title}
**Core Idea:** {1 to 2 sentences}
**Target Audience:** {who this is for}
**Why This Will Perform:** {CTR + retention reasoning}
**Pattern or Trend:** {pattern, competitor gap, or market signal}
**Suggested Format:** {tutorial / breakdown / comparison / experiment / case study / rant / build-in-public}
**Effort Level:** {low / medium / high}
**Expected Upside:** {low / medium / high}
```

If the evidence is weak or mixed, say so explicitly rather than forcing confidence.

After the ideas, add:

```markdown
## Competitive Notes
- {what competitors are doing well}
- {what they are missing}
- {how these angles differentiate}
```

## Working Rules

- Prioritize 3 strong ideas over 10 weak ones
- Prefer angles with a story, tension, mistake, benchmark, or opinionated takeaway
- If the topic is hot but crowded, shift to a narrower or more opinionated angle
- If the topic is technically important but not clickable, say that clearly
- If the topic is timely, call out the time sensitivity and why the window may matter
- If a claim is based on pattern recognition rather than direct evidence, label it as an inference
- Do not write scripts
- Do not make the final choice for the creator
- Do not pretend a weak topic is good
