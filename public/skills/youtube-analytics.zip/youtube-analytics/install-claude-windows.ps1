#!/usr/bin/env pwsh
[CmdletBinding()]
param(
    [string]$Dest,
    [switch]$Overwrite,
    [switch]$DryRun,
    [switch]$Help
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Show-Usage {
@"
Usage: pwsh -File .\install-claude-windows.ps1 [options]

Install the current skill into Claude Code as a user-level subagent.

Options:
  -Dest <path>     Override destination agents directory
  -Overwrite       Replace an existing installed agent
  -DryRun          Show planned actions without changing files
  -Help            Show this help

Examples:
  pwsh -File .\install-claude-windows.ps1
  pwsh -File .\install-claude-windows.ps1 -Dest "$HOME\.claude\agents"
  pwsh -File .\install-claude-windows.ps1 -Overwrite
"@
}

if ($Help) {
    Show-Usage
    exit 0
}

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillName = Split-Path -Leaf $ScriptDir

function Resolve-Destination {
    if ($HOME) {
        return (Join-Path $HOME '.claude\agents')
    }

    if ($env:USERPROFILE) {
        return (Join-Path $env:USERPROFILE '.claude\agents')
    }

    throw 'Unable to resolve destination: neither HOME nor USERPROFILE is set.'
}

if (-not $Dest) {
    $Dest = Resolve-Destination
}

$AgentFile = Join-Path $Dest ($SkillName + '.md')
$SupportDir = Join-Path $Dest $SkillName

Write-Host "Skill: $SkillName"
Write-Host "Agent file: $AgentFile"
Write-Host "Support directory: $SupportDir"
Write-Host "Overwrite: $($Overwrite.IsPresent)"
Write-Host "Dry run: $($DryRun.IsPresent)"

if ((Test-Path -LiteralPath $AgentFile) -or (Test-Path -LiteralPath $SupportDir)) {
    if (-not $Overwrite) {
        throw "Claude installation already exists for $SkillName.`nRun again with -Overwrite to replace it."
    }

    if ($DryRun) {
        Write-Host "[dry-run] Remove-Item -Force $AgentFile"
        Write-Host "[dry-run] Remove-Item -Recurse -Force $SupportDir"
    } else {
        if (Test-Path -LiteralPath $AgentFile) {
            Remove-Item -LiteralPath $AgentFile -Force
        }
        if (Test-Path -LiteralPath $SupportDir) {
            Remove-Item -LiteralPath $SupportDir -Recurse -Force
        }
    }
}

if ($DryRun) {
    Write-Host "[dry-run] New-Item -ItemType Directory -Force -Path $Dest"
    Write-Host "[dry-run] Copy-Item -LiteralPath $ScriptDir -Destination $SupportDir -Recurse"
    Write-Host "[dry-run] rewrite $SupportDir\SKILL.md -> $AgentFile"
    exit 0
}

New-Item -ItemType Directory -Force -Path $Dest | Out-Null
Copy-Item -LiteralPath $ScriptDir -Destination $SupportDir -Recurse

$SupportDirForward = $SupportDir -replace '\\', '/'
$Content = Get-Content -LiteralPath (Join-Path $SupportDir 'SKILL.md') -Raw
$Content = $Content.Replace('subskills/', "$SupportDirForward/subskills/")
$Content = $Content.Replace('scripts/', "$SupportDirForward/scripts/")
$Content = $Content.Replace('examples/', "$SupportDirForward/examples/")
$Content = $Content.Replace('agents/', "$SupportDirForward/agents/")
$Content = $Content.Replace('tools/', "$SupportDirForward/tools/")
Set-Content -LiteralPath $AgentFile -Value $Content -NoNewline

Write-Host "Installed $SkillName into Claude Code. Restart Claude Code or start a new session to pick up the subagent."
