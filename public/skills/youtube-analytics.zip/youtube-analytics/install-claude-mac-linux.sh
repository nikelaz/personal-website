#!/usr/bin/env sh

set -eu

SCRIPT_DIR=$(
  CDPATH= cd -- "$(dirname -- "$0")" && pwd
)
SKILL_NAME=$(basename "$SCRIPT_DIR")
DEST=""
OVERWRITE=0
DRY_RUN=0

usage() {
  cat <<USAGE
Usage: ./install-claude-mac-linux.sh [options]

Install the current skill into Claude Code as a user-level subagent.

Options:
  --dest <path>    Override destination agents directory
  --overwrite      Replace an existing installed agent
  --dry-run        Show planned actions without changing files
  --help           Show this help

Examples:
  ./install-claude-mac-linux.sh
  ./install-claude-mac-linux.sh --dest "$HOME/.claude/agents"
  ./install-claude-mac-linux.sh --overwrite
USAGE
}

resolve_default_dest() {
  if [ -n "${HOME:-}" ]; then
    printf '%s/.claude/agents\n' "$HOME"
  else
    printf >&2 'Unable to resolve destination: HOME is not set.\n'
    exit 1
  fi
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --dest)
      shift
      [ "$#" -gt 0 ] || { printf >&2 '--dest requires a path.\n'; exit 1; }
      DEST=$1
      ;;
    --overwrite)
      OVERWRITE=1
      ;;
    --dry-run)
      DRY_RUN=1
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      printf >&2 'Unknown argument: %s\n' "$1"
      usage
      exit 1
      ;;
  esac
  shift
done

if [ -z "$DEST" ]; then
  DEST=$(resolve_default_dest)
fi

AGENT_FILE="$DEST/$SKILL_NAME.md"
SUPPORT_DIR="$DEST/$SKILL_NAME"

printf 'Skill: %s\n' "$SKILL_NAME"
printf 'Agent file: %s\n' "$AGENT_FILE"
printf 'Support directory: %s\n' "$SUPPORT_DIR"
printf 'Overwrite: %s\n' "$OVERWRITE"
printf 'Dry run: %s\n' "$DRY_RUN"

if [ -e "$AGENT_FILE" ] || [ -e "$SUPPORT_DIR" ] || [ -L "$AGENT_FILE" ] || [ -L "$SUPPORT_DIR" ]; then
  if [ "$OVERWRITE" -eq 0 ]; then
    printf >&2 'Claude installation already exists for %s. Run again with --overwrite to replace it.\n' "$SKILL_NAME"
    exit 1
  fi

  if [ "$DRY_RUN" -eq 0 ]; then
    rm -rf "$AGENT_FILE" "$SUPPORT_DIR"
  else
    printf '[dry-run] rm -rf %s %s\n' "$AGENT_FILE" "$SUPPORT_DIR"
  fi
fi

if [ "$DRY_RUN" -eq 1 ]; then
  printf '[dry-run] mkdir -p %s\n' "$DEST"
  printf '[dry-run] cp -R %s %s\n' "$SCRIPT_DIR" "$SUPPORT_DIR"
  printf '[dry-run] rewrite %s/SKILL.md -> %s\n' "$SUPPORT_DIR" "$AGENT_FILE"
  exit 0
fi

mkdir -p "$DEST"
cp -R "$SCRIPT_DIR" "$SUPPORT_DIR"

SUPPORT_DIR_FORWARD=$(printf '%s\n' "$SUPPORT_DIR" | sed 's#\\#/#g')
escaped_support_dir=$(printf '%s\n' "$SUPPORT_DIR_FORWARD" | sed 's/[&]/\\&/g')

sed \
  -e "s#subskills/#$escaped_support_dir/subskills/#g" \
  -e "s#scripts/#$escaped_support_dir/scripts/#g" \
  -e "s#examples/#$escaped_support_dir/examples/#g" \
  -e "s#agents/#$escaped_support_dir/agents/#g" \
  -e "s#tools/#$escaped_support_dir/tools/#g" \
  "$SUPPORT_DIR/SKILL.md" > "$AGENT_FILE"

printf 'Installed %s into Claude Code. Restart Claude Code or start a new session to pick up the subagent.\n' "$SKILL_NAME"
