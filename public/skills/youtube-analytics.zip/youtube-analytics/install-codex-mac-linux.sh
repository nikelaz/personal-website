#!/usr/bin/env sh

set -eu

SCRIPT_DIR=$(
  CDPATH= cd -- "$(dirname -- "$0")" && pwd
)
SKILL_NAME=$(basename "$SCRIPT_DIR")
DEST=""
OVERWRITE=0
DRY_RUN=0

usage() {
  cat <<USAGE
Usage: ./install-codex-mac-linux.sh [options]

Install the current skill into Codex's user-level skills directory.

Options:
  --dest <path>    Override destination skills directory
  --overwrite      Replace an existing installed skill
  --dry-run        Show planned actions without changing files
  --help           Show this help

Examples:
  ./install-codex-mac-linux.sh
  ./install-codex-mac-linux.sh --dest "$HOME/.codex/skills"
  ./install-codex-mac-linux.sh --overwrite
USAGE
}

resolve_default_dest() {
  if [ -n "${CODEX_HOME:-}" ]; then
    printf '%s/skills\n' "$CODEX_HOME"
  elif [ -n "${HOME:-}" ]; then
    printf '%s/.codex/skills\n' "$HOME"
  else
    printf >&2 'Unable to resolve destination: neither CODEX_HOME nor HOME is set.\n'
    exit 1
  fi
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --dest)
      shift
      [ "$#" -gt 0 ] || { printf >&2 '--dest requires a path.\n'; exit 1; }
      DEST=$1
      ;;
    --overwrite)
      OVERWRITE=1
      ;;
    --dry-run)
      DRY_RUN=1
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      printf >&2 'Unknown argument: %s\n' "$1"
      usage
      exit 1
      ;;
  esac
  shift
done

if [ -z "$DEST" ]; then
  DEST=$(resolve_default_dest)
fi

TARGET="$DEST/$SKILL_NAME"

printf 'Skill: %s\n' "$SKILL_NAME"
printf 'Destination: %s\n' "$TARGET"
printf 'Overwrite: %s\n' "$OVERWRITE"
printf 'Dry run: %s\n' "$DRY_RUN"

if [ -e "$TARGET" ] || [ -L "$TARGET" ]; then
  if [ "$OVERWRITE" -eq 0 ]; then
    printf >&2 'Destination already exists: %s\nRun again with --overwrite to replace it.\n' "$TARGET"
    exit 1
  fi

  if [ "$DRY_RUN" -eq 0 ]; then
    rm -rf "$TARGET"
  else
    printf '[dry-run] rm -rf %s\n' "$TARGET"
  fi
fi

if [ "$DRY_RUN" -eq 0 ]; then
  mkdir -p "$DEST"
  cp -R "$SCRIPT_DIR" "$TARGET"
else
  printf '[dry-run] mkdir -p %s\n' "$DEST"
  printf '[dry-run] cp -R %s %s\n' "$SCRIPT_DIR" "$TARGET"
fi

printf 'Installed %s into Codex. Restart Codex to pick up the skill.\n' "$SKILL_NAME"
