#!/usr/bin/env pwsh
[CmdletBinding()]
param(
    [string]$Dest,
    [switch]$Overwrite,
    [switch]$DryRun,
    [switch]$Help
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Show-Usage {
@"
Usage: pwsh -File .\install-codex-windows.ps1 [options]

Install the current skill into Codex's user-level skills directory.

Options:
  -Dest <path>     Override destination skills directory
  -Overwrite       Replace an existing installed skill
  -DryRun          Show planned actions without changing files
  -Help            Show this help

Examples:
  pwsh -File .\install-codex-windows.ps1
  pwsh -File .\install-codex-windows.ps1 -Dest "$HOME\.codex\skills"
  pwsh -File .\install-codex-windows.ps1 -Overwrite
"@
}

if ($Help) {
    Show-Usage
    exit 0
}

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillName = Split-Path -Leaf $ScriptDir

function Resolve-Destination {
    if ($env:CODEX_HOME) {
        return (Join-Path $env:CODEX_HOME 'skills')
    }

    if ($HOME) {
        return (Join-Path $HOME '.codex\skills')
    }

    if ($env:USERPROFILE) {
        return (Join-Path $env:USERPROFILE '.codex\skills')
    }

    throw 'Unable to resolve destination: neither CODEX_HOME, HOME, nor USERPROFILE is set.'
}

if (-not $Dest) {
    $Dest = Resolve-Destination
}

$Target = Join-Path $Dest $SkillName

Write-Host "Skill: $SkillName"
Write-Host "Destination: $Target"
Write-Host "Overwrite: $($Overwrite.IsPresent)"
Write-Host "Dry run: $($DryRun.IsPresent)"

if (Test-Path -LiteralPath $Target) {
    if (-not $Overwrite) {
        throw "Destination already exists: $Target`nRun again with -Overwrite to replace it."
    }

    if ($DryRun) {
        Write-Host "[dry-run] Remove-Item -Recurse -Force $Target"
    } else {
        Remove-Item -LiteralPath $Target -Recurse -Force
    }
}

if ($DryRun) {
    Write-Host "[dry-run] New-Item -ItemType Directory -Force -Path $Dest"
    Write-Host "[dry-run] Copy-Item -LiteralPath $ScriptDir -Destination $Target -Recurse"
} else {
    New-Item -ItemType Directory -Force -Path $Dest | Out-Null
    Copy-Item -LiteralPath $ScriptDir -Destination $Target -Recurse
}

Write-Host "Installed $SkillName into Codex. Restart Codex to pick up the skill."
